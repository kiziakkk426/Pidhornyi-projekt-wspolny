# Projekt Wspólny 

To repozytorium służy do nauki współpracy na GitHub.

## Cel
Stworzyć wspólny dokument na temat: **„Jak bezpiecznie korzystać z internetu?”**

## Zasady
- Pracuj w zespołach 3-osobowych.
- Każdy członek zespołu tworzy własne repozytorium na podstawie tego (fork).
- Uczeń A dodaje ucznia B jako kolaboratora.
- Uczeń C tworzy pull request z własnymi zmianami.
