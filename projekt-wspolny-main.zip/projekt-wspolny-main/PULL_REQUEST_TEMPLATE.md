## Opis zmian

Opisz krótko, co zostało dodane lub zmienione.

## Powód zmian

Dlaczego te zmiany są potrzebne?

## Zespół

- Autor: [Twoje imię]
- Recenzent: [Imię recenzenta]
