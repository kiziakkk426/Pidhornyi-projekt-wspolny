# Instrukcja krok po kroku

1. Forkuj to repozytorium.
2. Zmień nazwę na `TwojeNazwisko`-projekt-wspólny
3. Utwórz folder `dokument/` jeśli go nie ma.
4. Dodaj plik `wersja1.md` z własnym pomysłem na tekst.
5. Zaproś kolegę/koleżankę jako kolaboratora.
6. Kolaborator edytuje `wersja2.md`.
7. Trzeci członek zespołu tworzy pull request z propozycją zmian do `wersja-finalna.md`.
8. Wspólnie zatwierdźcie zmiany.

linki do dokumentacji:

(https://docs.github.com/en/pull-requests)

(https://docs.github.com/en/repositories)
